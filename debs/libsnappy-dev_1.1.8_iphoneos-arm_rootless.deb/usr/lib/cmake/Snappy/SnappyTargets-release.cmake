#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Snappy::snappy" for configuration "Release"
set_property(TARGET Snappy::snappy APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Snappy::snappy PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/usr/lib/libsnappy.1.1.8.dylib"
  IMPORTED_SONAME_RELEASE "/usr/lib/libsnappy.1.dylib"
  )

list(APPEND _IMPORT_CHECK_TARGETS Snappy::snappy )
list(APPEND _IMPORT_CHECK_FILES_FOR_Snappy::snappy "${_IMPORT_PREFIX}/usr/lib/libsnappy.1.1.8.dylib" )

# Import target "Snappy::snappy-static" for configuration "Release"
set_property(TARGET Snappy::snappy-static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Snappy::snappy-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/usr/lib/libsnappy.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS Snappy::snappy-static )
list(APPEND _IMPORT_CHECK_FILES_FOR_Snappy::snappy-static "${_IMPORT_PREFIX}/usr/lib/libsnappy.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
