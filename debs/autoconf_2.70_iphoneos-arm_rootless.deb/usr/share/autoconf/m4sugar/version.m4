# This file is part of -*- Autoconf -*-.
# Version of Autoconf.
# Copyright (C) 1999, 2000, 2001, 2002, 2006, 2007, 2009
# Free Software Foundation, Inc.

m4_define([m4_PACKAGE_NAME],      [GNU Autoconf])
m4_define([m4_PACKAGE_TARNAME],   [autoconf])
m4_define([m4_PACKAGE_VERSION],   [2.70])
m4_define([m4_PACKAGE_STRING],    [GNU Autoconf 2.70])
m4_define([m4_PACKAGE_BUGREPORT], [bug-autoconf@gnu.org])
m4_define([m4_PACKAGE_URL],       [https://www.gnu.org/software/autoconf/])
m4_define([m4_PACKAGE_YEAR],      [2020])
