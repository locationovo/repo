# Install script for directory: /Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "true")
endif()

# Set default install directory permissions.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/objdump")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/usr/share/games/fortunes/art;/usr/share/games/fortunes/art.dat;/usr/share/games/fortunes/art.u8;/usr/share/games/fortunes/ascii-art;/usr/share/games/fortunes/ascii-art.dat;/usr/share/games/fortunes/ascii-art.u8;/usr/share/games/fortunes/computers;/usr/share/games/fortunes/computers.dat;/usr/share/games/fortunes/computers.u8;/usr/share/games/fortunes/cookie;/usr/share/games/fortunes/cookie.dat;/usr/share/games/fortunes/cookie.u8;/usr/share/games/fortunes/definitions;/usr/share/games/fortunes/definitions.dat;/usr/share/games/fortunes/definitions.u8;/usr/share/games/fortunes/disclaimer;/usr/share/games/fortunes/disclaimer.dat;/usr/share/games/fortunes/disclaimer.u8;/usr/share/games/fortunes/drugs;/usr/share/games/fortunes/drugs.dat;/usr/share/games/fortunes/drugs.u8;/usr/share/games/fortunes/education;/usr/share/games/fortunes/education.dat;/usr/share/games/fortunes/education.u8;/usr/share/games/fortunes/ethnic;/usr/share/games/fortunes/ethnic.dat;/usr/share/games/fortunes/ethnic.u8;/usr/share/games/fortunes/food;/usr/share/games/fortunes/food.dat;/usr/share/games/fortunes/food.u8;/usr/share/games/fortunes/fortunes;/usr/share/games/fortunes/fortunes.dat;/usr/share/games/fortunes/fortunes.u8;/usr/share/games/fortunes/goedel;/usr/share/games/fortunes/goedel.dat;/usr/share/games/fortunes/goedel.u8;/usr/share/games/fortunes/humorists;/usr/share/games/fortunes/humorists.dat;/usr/share/games/fortunes/humorists.u8;/usr/share/games/fortunes/kids;/usr/share/games/fortunes/kids.dat;/usr/share/games/fortunes/kids.u8;/usr/share/games/fortunes/law;/usr/share/games/fortunes/law.dat;/usr/share/games/fortunes/law.u8;/usr/share/games/fortunes/linuxcookie;/usr/share/games/fortunes/linuxcookie.dat;/usr/share/games/fortunes/linuxcookie.u8;/usr/share/games/fortunes/literature;/usr/share/games/fortunes/literature.dat;/usr/share/games/fortunes/literature.u8;/usr/share/games/fortunes/love;/usr/share/games/fortunes/love.dat;/usr/share/games/fortunes/love.u8;/usr/share/games/fortunes/magic;/usr/share/games/fortunes/magic.dat;/usr/share/games/fortunes/magic.u8;/usr/share/games/fortunes/medicine;/usr/share/games/fortunes/medicine.dat;/usr/share/games/fortunes/medicine.u8;/usr/share/games/fortunes/men-women;/usr/share/games/fortunes/men-women.dat;/usr/share/games/fortunes/men-women.u8;/usr/share/games/fortunes/miscellaneous;/usr/share/games/fortunes/miscellaneous.dat;/usr/share/games/fortunes/miscellaneous.u8;/usr/share/games/fortunes/news;/usr/share/games/fortunes/news.dat;/usr/share/games/fortunes/news.u8;/usr/share/games/fortunes/people;/usr/share/games/fortunes/people.dat;/usr/share/games/fortunes/people.u8;/usr/share/games/fortunes/pets;/usr/share/games/fortunes/pets.dat;/usr/share/games/fortunes/pets.u8;/usr/share/games/fortunes/platitudes;/usr/share/games/fortunes/platitudes.dat;/usr/share/games/fortunes/platitudes.u8;/usr/share/games/fortunes/politics;/usr/share/games/fortunes/politics.dat;/usr/share/games/fortunes/politics.u8;/usr/share/games/fortunes/pratchett;/usr/share/games/fortunes/pratchett.dat;/usr/share/games/fortunes/pratchett.u8;/usr/share/games/fortunes/riddles;/usr/share/games/fortunes/riddles.dat;/usr/share/games/fortunes/riddles.u8;/usr/share/games/fortunes/science;/usr/share/games/fortunes/science.dat;/usr/share/games/fortunes/science.u8;/usr/share/games/fortunes/songs-poems;/usr/share/games/fortunes/songs-poems.dat;/usr/share/games/fortunes/songs-poems.u8;/usr/share/games/fortunes/sports;/usr/share/games/fortunes/sports.dat;/usr/share/games/fortunes/sports.u8;/usr/share/games/fortunes/startrek;/usr/share/games/fortunes/startrek.dat;/usr/share/games/fortunes/startrek.u8;/usr/share/games/fortunes/tao;/usr/share/games/fortunes/tao.dat;/usr/share/games/fortunes/tao.u8;/usr/share/games/fortunes/translate-me;/usr/share/games/fortunes/translate-me.dat;/usr/share/games/fortunes/translate-me.u8;/usr/share/games/fortunes/wisdom;/usr/share/games/fortunes/wisdom.dat;/usr/share/games/fortunes/wisdom.u8;/usr/share/games/fortunes/work;/usr/share/games/fortunes/work.dat;/usr/share/games/fortunes/work.u8;/usr/share/games/fortunes/linux;/usr/share/games/fortunes/linux.dat;/usr/share/games/fortunes/linux.u8;/usr/share/games/fortunes/perl;/usr/share/games/fortunes/perl.dat;/usr/share/games/fortunes/perl.u8;/usr/share/games/fortunes/knghtbrd;/usr/share/games/fortunes/knghtbrd.dat;/usr/share/games/fortunes/knghtbrd.u8;/usr/share/games/fortunes/paradoxum;/usr/share/games/fortunes/paradoxum.dat;/usr/share/games/fortunes/paradoxum.u8;/usr/share/games/fortunes/zippy;/usr/share/games/fortunes/zippy.dat;/usr/share/games/fortunes/zippy.u8;/usr/share/games/fortunes/debian;/usr/share/games/fortunes/debian.dat;/usr/share/games/fortunes/debian.u8")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
file(INSTALL DESTINATION "/usr/share/games/fortunes" TYPE FILE FILES
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/art"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/art.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/art.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/ascii-art"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/ascii-art.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/ascii-art.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/computers"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/computers.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/computers.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/cookie"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/cookie.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/cookie.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/definitions"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/definitions.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/definitions.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/disclaimer"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/disclaimer.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/disclaimer.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/drugs"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/drugs.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/drugs.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/education"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/education.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/education.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/ethnic"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/ethnic.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/ethnic.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/food"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/food.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/food.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/fortunes"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/fortunes.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/fortunes.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/goedel"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/goedel.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/goedel.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/humorists"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/humorists.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/humorists.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/kids"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/kids.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/kids.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/law"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/law.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/law.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/linuxcookie"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/linuxcookie.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/linuxcookie.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/literature"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/literature.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/literature.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/love"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/love.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/love.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/magic"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/magic.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/magic.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/medicine"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/medicine.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/medicine.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/men-women"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/men-women.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/men-women.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/miscellaneous"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/miscellaneous.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/miscellaneous.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/news"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/news.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/news.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/people"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/people.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/people.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/pets"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/pets.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/pets.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/platitudes"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/platitudes.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/platitudes.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/politics"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/politics.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/politics.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/pratchett"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/pratchett.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/pratchett.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/riddles"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/riddles.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/riddles.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/science"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/science.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/science.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/songs-poems"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/songs-poems.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/songs-poems.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/sports"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/sports.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/sports.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/startrek"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/startrek.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/startrek.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/tao"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/tao.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/tao.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/translate-me"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/translate-me.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/translate-me.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/wisdom"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/wisdom.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/wisdom.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/work"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/work.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/work.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/linux"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/linux.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/linux.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/perl"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/perl.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/perl.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/knghtbrd"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/knghtbrd.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/knghtbrd.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/paradoxum"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/paradoxum.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/paradoxum.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/zippy"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/zippy.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/zippy.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/debian"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/debian.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/debian.u8"
    )
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for each subdirectory.
  include("/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/cmake_install.cmake")

endif()

