# Install script for directory: /Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "true")
endif()

# Set default install directory permissions.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/objdump")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/usr/share/games/fortunes/off/art;/usr/share/games/fortunes/off/art.dat;/usr/share/games/fortunes/off/art.u8;/usr/share/games/fortunes/off/astrology;/usr/share/games/fortunes/off/astrology.dat;/usr/share/games/fortunes/off/astrology.u8;/usr/share/games/fortunes/off/atheism;/usr/share/games/fortunes/off/atheism.dat;/usr/share/games/fortunes/off/atheism.u8;/usr/share/games/fortunes/off/black-humor;/usr/share/games/fortunes/off/black-humor.dat;/usr/share/games/fortunes/off/black-humor.u8;/usr/share/games/fortunes/off/cookie;/usr/share/games/fortunes/off/cookie.dat;/usr/share/games/fortunes/off/cookie.u8;/usr/share/games/fortunes/off/debian;/usr/share/games/fortunes/off/debian.dat;/usr/share/games/fortunes/off/debian.u8;/usr/share/games/fortunes/off/definitions;/usr/share/games/fortunes/off/definitions.dat;/usr/share/games/fortunes/off/definitions.u8;/usr/share/games/fortunes/off/drugs;/usr/share/games/fortunes/off/drugs.dat;/usr/share/games/fortunes/off/drugs.u8;/usr/share/games/fortunes/off/ethnic;/usr/share/games/fortunes/off/ethnic.dat;/usr/share/games/fortunes/off/ethnic.u8;/usr/share/games/fortunes/off/fortunes;/usr/share/games/fortunes/off/fortunes.dat;/usr/share/games/fortunes/off/fortunes.u8;/usr/share/games/fortunes/off/hphobia;/usr/share/games/fortunes/off/hphobia.dat;/usr/share/games/fortunes/off/hphobia.u8;/usr/share/games/fortunes/off/knghtbrd;/usr/share/games/fortunes/off/knghtbrd.dat;/usr/share/games/fortunes/off/knghtbrd.u8;/usr/share/games/fortunes/off/limerick;/usr/share/games/fortunes/off/limerick.dat;/usr/share/games/fortunes/off/limerick.u8;/usr/share/games/fortunes/off/linux;/usr/share/games/fortunes/off/linux.dat;/usr/share/games/fortunes/off/linux.u8;/usr/share/games/fortunes/off/misandry;/usr/share/games/fortunes/off/misandry.dat;/usr/share/games/fortunes/off/misandry.u8;/usr/share/games/fortunes/off/miscellaneous;/usr/share/games/fortunes/off/miscellaneous.dat;/usr/share/games/fortunes/off/miscellaneous.u8;/usr/share/games/fortunes/off/misogyny;/usr/share/games/fortunes/off/misogyny.dat;/usr/share/games/fortunes/off/misogyny.u8;/usr/share/games/fortunes/off/politics;/usr/share/games/fortunes/off/politics.dat;/usr/share/games/fortunes/off/politics.u8;/usr/share/games/fortunes/off/privates;/usr/share/games/fortunes/off/privates.dat;/usr/share/games/fortunes/off/privates.u8;/usr/share/games/fortunes/off/racism;/usr/share/games/fortunes/off/racism.dat;/usr/share/games/fortunes/off/racism.u8;/usr/share/games/fortunes/off/religion;/usr/share/games/fortunes/off/religion.dat;/usr/share/games/fortunes/off/religion.u8;/usr/share/games/fortunes/off/riddles;/usr/share/games/fortunes/off/riddles.dat;/usr/share/games/fortunes/off/riddles.u8;/usr/share/games/fortunes/off/sex;/usr/share/games/fortunes/off/sex.dat;/usr/share/games/fortunes/off/sex.u8;/usr/share/games/fortunes/off/songs-poems;/usr/share/games/fortunes/off/songs-poems.dat;/usr/share/games/fortunes/off/songs-poems.u8;/usr/share/games/fortunes/off/vulgarity;/usr/share/games/fortunes/off/vulgarity.dat;/usr/share/games/fortunes/off/vulgarity.u8;/usr/share/games/fortunes/off/zippy;/usr/share/games/fortunes/off/zippy.dat;/usr/share/games/fortunes/off/zippy.u8")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
file(INSTALL DESTINATION "/usr/share/games/fortunes/off" TYPE FILE FILES
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/art"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/art.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/art.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/astrology"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/astrology.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/astrology.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/atheism"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/atheism.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/atheism.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/black-humor"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/black-humor.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/black-humor.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/cookie"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/cookie.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/cookie.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/debian"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/debian.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/debian.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/definitions"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/definitions.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/definitions.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/drugs"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/drugs.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/drugs.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/ethnic"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/ethnic.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/ethnic.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/fortunes"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/fortunes.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/fortunes.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/hphobia"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/hphobia.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/hphobia.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/knghtbrd"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/knghtbrd.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/knghtbrd.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/limerick"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/limerick.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/limerick.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/linux"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/linux.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/linux.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/misandry"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/misandry.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/misandry.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/miscellaneous"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/miscellaneous.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/miscellaneous.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/misogyny"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/misogyny.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/misogyny.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/politics"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/politics.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/politics.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/privates"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/privates.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/privates.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/racism"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/racism.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/racism.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/religion"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/religion.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/religion.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/riddles"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/riddles.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/riddles.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/sex"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/sex.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/sex.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/songs-poems"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/songs-poems.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/songs-poems.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/vulgarity"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/vulgarity.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/vulgarity.u8"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/zippy"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/zippy.dat"
    "/Users/haydenseay/GitHub/Procursus/build_work/iphoneos-arm64/1600/fortune-mod/datfiles/off/rotated/zippy.u8"
    )
endif()

