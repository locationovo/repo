#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EBML::ebml" for configuration "Release"
set_property(TARGET EBML::ebml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EBML::ebml PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libebml.5.0.0.dylib"
  IMPORTED_SONAME_RELEASE "/usr/lib/libebml.5.dylib"
  )

list(APPEND _IMPORT_CHECK_TARGETS EBML::ebml )
list(APPEND _IMPORT_CHECK_FILES_FOR_EBML::ebml "${_IMPORT_PREFIX}/lib/libebml.5.0.0.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
